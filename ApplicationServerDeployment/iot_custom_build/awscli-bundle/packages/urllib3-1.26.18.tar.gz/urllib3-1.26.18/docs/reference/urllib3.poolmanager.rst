Pool Manager
============

.. autoclass:: urllib3.PoolManager
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: urllib3.ProxyManager
    :members:
    :undoc-members:
    :show-inheritance:
